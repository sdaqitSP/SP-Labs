n=input("Enter words: ")
#t=tuple(n)
li=n.split(",")


for values in li:
	print (values.upper())
#print (li.upper())
