n=input("Enter words: ")
#t=tuple(n)
li=n.split(",")
li.sort()


print (li)
